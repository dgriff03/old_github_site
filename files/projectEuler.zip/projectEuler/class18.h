#ifndef class18_H
#define class18_H

#include <iostream>
using namespace std;

struct Node{
  int num;
  Node* next1;
  Node* next2;
  int id;
};


class class18{
public:
	class18();
						//must do act1 before act2
	void act();			//preforms action 1
	void act2();		//preforms action 2
private:
	void data_intake();	//takes in data
	void build_tree();	//builds tree off id, calls find_id _add
	void summation();	//sums numbers to find largest sum
	void print();		//prints larget sum
	Node* greater(Node* iter);
	Node* numbers();
	Node* find_id_add(int nID);
	Node** array;
	int sum;
	Node* head;
	int num_in;
	int max_inrow;
	void summation2();
};



#endif
