#include "class18.h"
#include <iostream>

class18::class18(){
	max_inrow = 100;		//longest row
	num_in = ((max_inrow + 1) * (max_inrow)) / 2;	//number of items in triangle
	array = new Node*[num_in];	//array of all numbers
	sum = 0;					//initalizes sum at zero
	head = NULL;				//start of tree
}

void class18::data_intake(){
	for(int i = 0;i < num_in;i++){ 	//intakes items into array
		Node* temp = new Node;
		temp->id = i;
		cin >> temp->num;
		array[i]=temp;
	}
}

//used to find the address of an item by its id
Node* class18::find_id_add(int nID){	
	for(int i = 0;i < num_in;i++){ 
		if(array[i]->id == nID){return array[i];}
	}
	return NULL;
}

//builds tree from array, uses find_id_add
void class18::build_tree(){
	int num_inrow = 1;
	int counter = 0; //keeps track of spot in row (0 through num_inrow-1)
	for(int i = 0;i < num_in;i++){ 
		if(counter == num_inrow){
			num_inrow++;
			counter = 0;
		}
		if(num_inrow != max_inrow){
			array[i]->next1 = find_id_add(array[i]->id + num_inrow);
			array[i]->next2 = find_id_add(array[i]->id + num_inrow + 1);
		}
		if(num_inrow == max_inrow){	//sets all bottom next to NULL
			array[i]->next1 = NULL;
			array[i]->next2 = NULL;
		}
		counter++;
	}
	head = array[0];
}

//returns null if either child is NULL
//returns greater value of the two children
Node* class18::greater(Node* iter){	//finds greater of 2 children
   if(iter->next1 == NULL || iter->next2==NULL){
	return NULL;
    }
   if(iter->next1->num > iter->next2->num){
     return iter->next1;

   }
   return iter->next2;

}
//looks 2 deep and finds greater of left branch verses right branch
Node* class18::numbers(){
	int sumL = 0;
	int sumR = 0;
	Node* iter;
	if(head->next1 != NULL && head->next2 != NULL){
		iter = head->next1;
		sumL += iter->num;
		if(iter->next1 != NULL){
			sumL += greater(iter)->num;
		}
		iter = head->next2;
		sumR += iter->num;
		if(iter->next1 != NULL){
			sumR += greater(iter)->num;
		}
		if(sumL > sumR){
			return head->next1;
		}
		return head->next2;
	}
	else{
		return NULL;
	}
}

//goes through tree looking for greater values 2 deep to choose path
//this method worked for problem 18 but not 67
void class18::summation(){
	while(head != NULL){
		sum += head->num;
		cout << "sum: " << sum << "   num: " << head->num << endl;
		head = numbers();
	}
}

//goes from bottom up summing from the second to last row
//sums greater of two children to its own value
//goes up the tree till the value of the top item is 
//the value of the largest sum value of the tree
void class18::summation2(){
	Node* max;
	for(int i = num_in - max_inrow -1; i >=0; i--){
		max = greater(array[i]);
		array[i]->num += max->num;
	}
	sum = array[0]->num;
}

void class18::print(){
	cout << "sum: ";
	cout << sum << endl;
}

//solves for problem 18 not 67
void class18::act(){
	data_intake();
	build_tree();
	summation();
	print();
}

//solves both problem 18 and 67
void class18::act2(){
	summation2();
	print();	
}