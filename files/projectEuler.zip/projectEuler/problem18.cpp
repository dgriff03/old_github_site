
#include "class18.h"
#include <iostream>
using namespace std;

int main(){
	class18 Test;
	Test.act();
	Test.act2();
}